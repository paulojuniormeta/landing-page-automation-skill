# Landing Page Automation Workflow Guide

## 8-Phase Automation Process

### Phase 1: Analysis
**Goal:** Extract content and design from both URLs

**Steps:**
1. Access original URL
2. Parse HTML structure
3. Extract text content (headlines, descriptions, CTAs)
4. Identify tracking scripts (Hotmart, Google Analytics, Facebook Pixel)
5. Extract email addresses and contact information
6. Access reference URL
7. Analyze design (colors, fonts, layout)
8. Extract CSS variables and Tailwind classes

**Output:** Structured data with content and design specifications

### Phase 2: Generation
**Goal:** Generate React components with mobile-first design

**Steps:**
1. Create TopBar.tsx (urgent offer/announcement)
2. Create Hero.tsx (headline, video, primary CTA)
3. Create Pricing.tsx (price, payment methods, CTA)
4. Create Footer.tsx (links, contact, compliance)
5. Create index.css (Tailwind configuration)
6. Generate App.tsx (component orchestration)
7. Create package.json (dependencies)

**Output:** Complete React component library

### Phase 3: Structure
**Goal:** Create project directory structure

**Steps:**
1. Create project directory
2. Create client/ subdirectory
3. Create src/ with components/, pages/, lib/
4. Create public/ for static files
5. Create server/ placeholder
6. Copy generated components
7. Copy configuration files

**Output:** Complete project structure ready for build

### Phase 4: Configuration
**Goal:** Configure project for deployment

**Steps:**
1. Create vercel.json (deployment config)
2. Create .gitignore (exclude node_modules, dist)
3. Create .env.example (environment variables)
4. Update package.json with build scripts
5. Configure Tailwind CSS
6. Add Google Fonts if needed
7. Configure meta tags and favicon

**Output:** Project ready for build and deployment

### Phase 5: Build
**Goal:** Compile and test the project

**Steps:**
1. Install dependencies (pnpm install)
2. Run TypeScript check (tsc --noEmit)
3. Build for production (pnpm build)
4. Verify build output
5. Check for errors or warnings
6. Generate build report

**Output:** Compiled project ready for deployment

### Phase 6: GitHub
**Goal:** Push code to GitHub repository

**Steps:**
1. Initialize git repository (git init)
2. Add all files (git add .)
3. Create initial commit (git commit -m "Initial commit")
4. Add remote origin (git remote add origin)
5. Push to GitHub (git push -u origin main)
6. Verify files on GitHub
7. Create GitHub Actions workflow (optional)

**Output:** Code available on GitHub for Vercel to deploy

### Phase 7: Vercel
**Goal:** Deploy to Vercel and get public URL

**Steps:**
1. Connect GitHub account to Vercel
2. Select repository
3. Configure build settings
4. Set environment variables
5. Trigger initial deploy
6. Monitor build logs
7. Verify deployment success
8. Get public URL

**Output:** Live website on Vercel with public URL

### Phase 8: Finalization
**Goal:** Validate and document the deployment

**Steps:**
1. Access public URL
2. Test on desktop (Chrome, Firefox, Safari)
3. Test on mobile (iOS, Android)
4. Validate all CTAs work
5. Check tracking scripts are loaded
6. Generate deployment report
7. Save configuration for future reference
8. Return results to user

**Output:** Validated, production-ready landing page

---

## Error Handling

### Common Issues and Solutions

**Issue: Repository empty error**
- **Cause:** Code not pushed to GitHub before Vercel deploy
- **Solution:** Ensure Phase 6 completes successfully before Phase 7

**Issue: Build failed on Vercel**
- **Cause:** Missing dependencies or configuration issues
- **Solution:** Check build logs, verify package.json, test locally first

**Issue: Page not responsive**
- **Cause:** Missing Tailwind breakpoints
- **Solution:** Review component classes, add sm:, md:, lg: prefixes

**Issue: CTA links not working**
- **Cause:** Incorrect URL or missing href attribute
- **Solution:** Verify URLs in component, test links manually

**Issue: Tracking scripts not firing**
- **Cause:** Scripts not included in index.html or blocked by CSP
- **Solution:** Add scripts to head, check Content Security Policy

---

## Mobile-First Best Practices

### Design Principles
1. Start with mobile layout (single column)
2. Add complexity at larger breakpoints
3. Use flexible units (%, rem, em)
4. Test on real devices, not just browser emulation
5. Prioritize touch targets (44px minimum)

### Typography
- Mobile: 16px base font size (prevents zoom)
- Tablet: 18px base font size
- Desktop: 16-20px base font size
- Line height: 1.5-1.6 for readability
- Use system fonts or preload web fonts

### Layout
- Mobile: Single column, full-width
- Tablet: 2 columns where appropriate
- Desktop: 2-3 columns with max-width
- Use CSS Grid or Flexbox, not floats
- Maintain consistent spacing (8px grid)

### Performance
- Minimize CSS (Tailwind does this)
- Defer non-critical JavaScript
- Optimize images (WebP with fallbacks)
- Use lazy loading for below-fold content
- Monitor Core Web Vitals

---

## Customization After Deployment

### Changing Text
1. Edit component file (e.g., Hero.tsx)
2. Update text content
3. Commit and push to GitHub
4. Vercel auto-deploys on push

### Changing Colors
1. Edit index.css
2. Update CSS variables
3. Commit and push
4. Vercel auto-deploys

### Adding Images
1. Use manus-upload-file --webdev
2. Get returned URL
3. Add to component: `<img src="URL" />`
4. Commit and push

### Modifying Layout
1. Edit component JSX
2. Adjust Tailwind classes
3. Test on mobile and desktop
4. Commit and push

---

## Validation Checklist

### Pre-Deployment
- [ ] All components render without errors
- [ ] Mobile layout looks correct
- [ ] Desktop layout looks correct
- [ ] All CTAs have correct URLs
- [ ] Tracking scripts are included
- [ ] Build completes successfully
- [ ] No console errors in local testing

### Post-Deployment
- [ ] Website loads on public URL
- [ ] Mobile view is responsive
- [ ] All CTAs work correctly
- [ ] Tracking pixels fire
- [ ] Email links work
- [ ] Forms submit (if applicable)
- [ ] Performance is acceptable (< 3s load time)

---

## Performance Metrics

### Target Metrics
- **First Contentful Paint (FCP):** < 1.8s
- **Largest Contentful Paint (LCP):** < 2.5s
- **Cumulative Layout Shift (CLS):** < 0.1
- **Time to Interactive (TTI):** < 3.8s

### Optimization Tips
1. Minimize JavaScript bundle
2. Optimize images (WebP format)
3. Use CSS minification (Tailwind)
4. Enable gzip compression
5. Use CDN for static assets
6. Defer non-critical scripts
7. Preload critical resources

---

## Security Considerations

### HTTPS
- All pages must use HTTPS
- Vercel provides free SSL certificates
- Automatic HTTPS redirect

### Content Security Policy
- Restrict script sources
- Allow only necessary domains
- Prevent inline scripts where possible

### Data Protection
- Don't store sensitive data in localStorage
- Use secure cookies (HttpOnly, Secure flags)
- Validate all user inputs
- Sanitize HTML content

### Tracking Scripts
- Verify tracking scripts are from trusted sources
- Check privacy policy compliance
- Ensure GDPR/CCPA compliance
- Use consent management if needed

---

## Monitoring and Maintenance

### Regular Checks
- Monitor error rates (Vercel dashboard)
- Check performance metrics
- Review analytics data
- Test CTAs periodically
- Verify tracking data

### Updates
- Keep dependencies updated
- Monitor security advisories
- Update content as needed
- Refresh design periodically
- Test on new devices/browsers

### Backups
- Keep code in Git (automatic with GitHub)
- Document configuration changes
- Save design specifications
- Archive analytics data
