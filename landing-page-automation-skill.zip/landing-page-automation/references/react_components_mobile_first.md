# React Components - Mobile-First Reference

## Overview

This reference contains the React component templates used in landing page automation. All components follow mobile-first design principles with Tailwind CSS breakpoints.

## Tailwind Breakpoints

| Breakpoint | Size | Usage |
|-----------|------|-------|
| Default | <640px | Mobile (base styles) |
| sm: | ≥640px | Small devices |
| md: | ≥768px | Tablets |
| lg: | ≥1024px | Desktops |
| xl: | ≥1280px | Large screens |

## Component Patterns

### Typography Scaling

**Mobile-first approach:**
```jsx
// Headline
<h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold">
  Headline
</h1>

// Subheadline
<h2 className="text-xl sm:text-2xl md:text-3xl">
  Subheadline
</h2>

// Body text
<p className="text-sm sm:text-base md:text-lg">
  Body text
</p>
```

### Spacing Scaling

**Padding and margins:**
```jsx
// Container padding
<div className="p-4 sm:p-6 md:p-8 lg:p-12">
  Content
</div>

// Gap between items
<div className="gap-4 sm:gap-6 md:gap-8">
  Items
</div>
```

### Grid Layouts

**Responsive grids:**
```jsx
// 1 column mobile → 2 columns tablet → 3 columns desktop
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
  {items.map(item => (
    <div key={item.id}>{item.content}</div>
  ))}
</div>
```

### Button Sizing

**Responsive buttons:**
```jsx
// Mobile: full-width, tablet+: auto
<button className="w-full sm:w-auto px-6 py-3 sm:px-8 sm:py-4">
  Call to Action
</button>
```

### Image Sizing

**Responsive images:**
```jsx
// Mobile: 100%, tablet+: constrained
<img 
  src="image.jpg" 
  className="w-full sm:w-3/4 md:w-1/2 lg:w-2/5"
  alt="Description"
/>
```

## TopBar Component

**Purpose:** Display urgent offer or announcement

**Mobile-first structure:**
```jsx
// Mobile: stacked, full-width
// Desktop: inline, centered
<div className="bg-orange-600 text-white py-2 px-4 sm:py-3 sm:px-6">
  <div className="text-center text-xs sm:text-sm md:text-base">
    OFERTA DE LANÇAMENTO POR TEMPO LIMITADO
  </div>
</div>
```

## Hero Component

**Purpose:** Main headline, video, and primary CTA

**Mobile-first structure:**
```jsx
<section className="py-8 sm:py-12 md:py-16 lg:py-20 px-4 sm:px-6">
  <div className="max-w-4xl mx-auto">
    {/* Headline */}
    <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl">
      Headline
    </h1>
    
    {/* Video */}
    <div className="mt-6 sm:mt-8 md:mt-10 aspect-video">
      <iframe
        className="w-full h-full"
        src="https://www.youtube.com/embed/VIDEO_ID"
      />
    </div>
    
    {/* CTA */}
    <button className="mt-6 sm:mt-8 w-full sm:w-auto">
      Call to Action
    </button>
  </div>
</section>
```

## Pricing Component

**Purpose:** Display price, payment methods, and purchase CTA

**Mobile-first structure:**
```jsx
<section className="py-8 sm:py-12 md:py-16 px-4 sm:px-6">
  <div className="max-w-2xl mx-auto text-center">
    {/* Price */}
    <div className="text-4xl sm:text-5xl md:text-6xl font-bold">
      R$ 63,90
    </div>
    
    {/* Payment methods */}
    <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row gap-4 justify-center">
      <span>💳 Cartão de Crédito</span>
      <span>💰 PIX</span>
      <span>🏦 Boleto</span>
    </div>
    
    {/* Security badge */}
    <div className="mt-6 sm:mt-8 flex items-center justify-center gap-2">
      ✅ Compra 100% Segura
    </div>
    
    {/* CTA */}
    <button className="mt-8 sm:mt-10 w-full sm:w-auto px-8 py-4">
      Comprar Agora
    </button>
  </div>
</section>
```

## Footer Component

**Purpose:** Links, contact info, compliance

**Mobile-first structure:**
```jsx
<footer className="bg-gray-900 text-white py-8 sm:py-12 px-4 sm:px-6">
  <div className="max-w-4xl mx-auto">
    {/* Links */}
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
      <div>
        <h4 className="font-bold mb-4">Links</h4>
        <ul className="space-y-2 text-sm">
          <li><a href="#">Termos</a></li>
          <li><a href="#">Privacidade</a></li>
        </ul>
      </div>
    </div>
    
    {/* Contact */}
    <div className="mt-8 sm:mt-12 text-center text-sm">
      <p>Email: <a href="mailto:contact@example.com">contact@example.com</a></p>
      <p>CNPJ: 00.000.000/0000-00</p>
    </div>
  </div>
</footer>
```

## Color Palette (Tailwind)

**Primary colors:**
- Background: `bg-white` (light) or `bg-gray-900` (dark)
- Primary: `bg-orange-600` (accent)
- Text: `text-gray-900` (dark) or `text-white` (light)

**Semantic colors:**
- Success: `bg-green-500`
- Error: `bg-red-500`
- Warning: `bg-yellow-500`
- Info: `bg-blue-500`

## Animation Patterns

**Fade in:**
```jsx
<div className="animate-fade-in">
  Content
</div>
```

**Slide in:**
```jsx
<div className="animate-slide-in-up">
  Content
</div>
```

**Hover effects:**
```jsx
<button className="hover:scale-105 transition-transform">
  Hover me
</button>
```

## Accessibility Considerations

- **Color contrast:** Ensure text contrast ratio ≥ 4.5:1
- **Touch targets:** Buttons ≥ 44px × 44px on mobile
- **Font sizes:** Minimum 16px on mobile to avoid zoom
- **Focus indicators:** Visible focus rings on interactive elements
- **Semantic HTML:** Use proper heading hierarchy (h1, h2, h3)

## Performance Tips

- **Image optimization:** Use WebP format with fallbacks
- **Lazy loading:** Defer off-screen images
- **CSS minification:** Tailwind handles this automatically
- **Font loading:** Use `font-display: swap` for Google Fonts
- **Bundle size:** Keep component libraries minimal

## Testing Checklist

- [ ] Test on actual mobile devices (not just browser emulation)
- [ ] Verify touch targets are large enough
- [ ] Check text readability at all sizes
- [ ] Test all CTAs and links
- [ ] Verify video embedding works
- [ ] Check form inputs are accessible
- [ ] Test on slow network (3G)
- [ ] Validate HTML and CSS
