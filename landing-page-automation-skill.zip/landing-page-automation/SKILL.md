---
name: landing-page-automation
description: Automate creation of modern mobile-first landing pages from existing URLs. Use for recreating sales pages with modern design, converting Hotmart pages to custom domains, building responsive landing pages quickly, or automating page creation for multiple products. Preserves original CTAs, tracking scripts, and content while applying mobile-first design principles.
---

# Landing Page Automation Skill

## Overview

This skill automates the complete process of recreating landing pages with modern, mobile-first design. Given two URLs (original page and design reference), the skill generates a production-ready React application with Tailwind CSS, deploys it to Vercel, and returns a public URL.

**Typical workflow:** 15-20 minutes from URLs to deployed website.

## When to Use This Skill

Use this skill when you need to:

- **Recreate sales pages** with modern design (e.g., Hotmart pages)
- **Update outdated landing pages** to mobile-first responsive design
- **Automate page creation** for multiple products or courses
- **Test new designs quickly** without manual coding
- **Preserve existing functionality** while improving appearance

The skill is particularly valuable when you have a page with good content but outdated design, and a reference page with design you like.

## Prerequisites

Before starting, prepare:

1. **Original URL** - The page you want to recreate (e.g., Hotmart sales page)
2. **Reference URL** - A page with design you like (e.g., modern SaaS landing page)
3. **GitHub account** with username
4. **GitHub Personal Access Token** (with repo scope)
5. **Vercel account** (free tier works fine)

## How It Works

The automation runs 8 sequential phases:

| Phase | Name | Purpose | Time |
|-------|------|---------|------|
| 1 | Analysis | Extract content and design from both URLs | 2 min |
| 2 | Generation | Generate React components with mobile-first design | 3 min |
| 3 | Structure | Create project directory and file structure | 1 min |
| 4 | Configuration | Configure Vercel, Git, and build settings | 1 min |
| 5 | Build | Compile project and verify no errors | 3 min |
| 6 | GitHub | Push code to GitHub repository | 2 min |
| 7 | Vercel | Deploy to Vercel and get public URL | 3 min |
| 8 | Finalization | Validate and document deployment | 1 min |

**Total time:** 15-20 minutes

## Usage

### Step 1: Prepare Information

Gather the following before starting:

```
Original URL: https://your-original-page.com
Reference URL: https://design-reference.com
Project name: my-landing-page
GitHub username: your-username
GitHub token: ghp_xxxxxxxxxxxx
```

### Step 2: Run the Automation

Execute the main script with your information:

```bash
python landing_page_automation.py \
  --original-url "https://original.com" \
  --reference-url "https://reference.com" \
  --project-name "my-project" \
  --github-username "your-username" \
  --github-token "ghp_token"
```

### Step 3: Monitor Progress

The script displays real-time progress through all 8 phases. Each phase shows:

- Phase number and name
- Current step being executed
- Status (success or error)

### Step 4: Access Your Page

After successful completion, you receive:

- **Public URL:** https://your-project.vercel.app
- **GitHub repository:** https://github.com/your-username/your-project
- **Deployment logs:** Available in Vercel dashboard

## What Gets Preserved

The automation extracts and preserves all important elements from the original page:

- **CTAs and links** - All buttons and links point to original destinations
- **Tracking scripts** - Hotmart, Google Analytics, Facebook Pixel, etc.
- **Contact information** - Email addresses and phone numbers
- **Content** - All text, headlines, descriptions
- **Compliance** - CNPJ, terms, privacy policy links

## What Gets Improved

The automation applies modern design principles from the reference page:

- **Mobile-first design** - Optimized for mobile, scales to desktop
- **Responsive layout** - Adapts to all screen sizes (sm, md, lg, xl breakpoints)
- **Modern typography** - Improved font hierarchy and readability
- **Color palette** - Extracted from reference page design
- **Animations** - Smooth transitions and hover effects
- **Performance** - Optimized for fast loading

## Mobile-First Implementation

All generated components follow mobile-first principles:

**Breakpoints used:**
- Mobile (default): less than 640px
- Tablet (sm): 640px and up
- Desktop (md): 768px and up
- Large (lg): 1024px and up
- XL (xl): 1280px and up

**Example responsive text:**
```jsx
<h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl">
  Headline scales from mobile to desktop
</h1>
```

## Components Generated

The automation creates these React components:

### TopBar
Displays urgent offer or announcement. Customizable text, closeable by user.

### Hero
Main section with headline, subheadline, embedded YouTube video, and primary CTA. Includes security badge.

### Pricing
Price display, payment methods (card, PIX, boleto), security badge, and purchase CTA.

### Footer
Links (terms, privacy), contact email, CNPJ, and compliance information.

### App.tsx
Routes and layout orchestration.

### index.css
Tailwind CSS configuration with custom theme variables.

## Customization After Deployment

After deployment, you can customize the page by editing files and pushing to GitHub. Vercel automatically redeploys on each push.

**Common customizations:**

```bash
# Change text
nano client/src/components/Hero.tsx
# Edit content, save, commit, push

# Change colors
nano client/src/index.css
# Edit CSS variables, save, commit, push

# Add images
manus-upload-file --webdev image.png
# Use returned URL in component
```

## Examples

### Example 1: Hotmart to Modern

```bash
python landing_page_automation.py \
  --original-url "https://paulocardoni.hotmart.host/automacao-claude-code-trafego" \
  --reference-url "https://nocodestartup.io/formacao-agentic-builder/" \
  --project-name "automacao-claude-code-vendas" \
  --github-username "paulojuniormeta" \
  --github-token "ghp_xxxxxxxxxxxxx"
```

**Result:** Modern landing page with Hotmart CTAs preserved, deployed to https://automacao-claude-code-vendas.vercel.app

### Example 2: Course Sales Page

```bash
python landing_page_automation.py \
  --original-url "https://my-course.com/sales" \
  --reference-url "https://example-modern.io/course/" \
  --project-name "my-course-2024" \
  --github-username "course-creator" \
  --github-token "ghp_xxxxxxxxxxxxx"
```

**Result:** Responsive course sales page with all original links and tracking preserved.

## Troubleshooting

### Issue: Repository empty error

**Cause:** Code not pushed to GitHub before Vercel deploy

**Solution:** Ensure Phase 6 completes successfully. Check GitHub repository has files.

### Issue: Build failed on Vercel

**Cause:** Missing dependencies or configuration issues

**Solution:** Check Vercel build logs, verify package.json, test locally first with pnpm build

### Issue: Page not responsive on mobile

**Cause:** Missing Tailwind breakpoints in components

**Solution:** Review component classes, ensure sm, md, lg prefixes are present

### Issue: CTA links not working

**Cause:** Incorrect URL or missing href attribute

**Solution:** Verify URLs in component file, test links manually

### Issue: Tracking scripts not firing

**Cause:** Scripts not included in HTML or blocked by CSP

**Solution:** Check index.html has script tags, verify Content Security Policy

## Advanced Features

### Custom Domain

After deployment, you can connect a custom domain:

1. Go to Vercel dashboard
2. Select project
3. Go to Settings and Domains
4. Add custom domain
5. Update DNS records
6. Verify domain

### Environment Variables

For sensitive data (API keys, tokens):

1. Create .env.local file
2. Add variables: VITE_API_KEY=xxx
3. Reference in code: import.meta.env.VITE_API_KEY
4. Never commit .env.local

### Analytics

Monitor page performance:

1. Vercel dashboard shows traffic and deployment history
2. Add Google Analytics for detailed user behavior
3. Monitor Core Web Vitals for performance

## Performance Optimization

The generated pages are optimized for performance:

- **CSS minification:** Tailwind handles automatically
- **Code splitting:** React lazy loading where applicable
- **Image optimization:** Use WebP format with fallbacks
- **Lazy loading:** Defer off-screen content
- **Caching:** Vercel CDN caches static assets

**Target metrics:**
- First Contentful Paint: less than 1.8s
- Largest Contentful Paint: less than 2.5s
- Cumulative Layout Shift: less than 0.1

## Security

The automation follows security best practices:

- **HTTPS:** All pages use HTTPS (Vercel provides free SSL)
- **No sensitive data:** Original sensitive info is never stored
- **Tracking scripts:** Only trusted tracking services included
- **Input validation:** All user inputs are sanitized
- **GDPR/CCPA:** Ensure compliance with privacy regulations

## Bundled Resources

This skill includes:

**Scripts:**
- landing_page_automation.py - Main orchestrator (8 phases)

**References:**
- react_components_mobile_first.md - Component templates and patterns
- workflow_guide.md - Detailed workflow documentation

## Next Steps After Deployment

1. **Test the page** on desktop and mobile
2. **Validate all CTAs** work correctly
3. **Check tracking** scripts are firing
4. **Customize content** as needed
5. **Monitor performance** in Vercel dashboard
6. **Share public URL** with team or audience

## Support and Documentation

For detailed information, refer to:

- **Component patterns:** See react_components_mobile_first.md for Tailwind examples
- **Workflow details:** See workflow_guide.md for 8-phase breakdown
- **Troubleshooting:** Check common issues section above

## Limitations

The automation works best when:

- Original page is publicly accessible
- Reference page has clear design patterns
- GitHub and Vercel accounts are active
- URLs are valid and responsive

The automation may need manual adjustment for:

- Complex JavaScript interactions
- Custom form handling
- Advanced animations
- Dynamic content loading
- Third-party integrations

## Version and Updates

**Current version:** 2.0 (Mobile-First)
**Last updated:** April 2026
**Status:** Production-ready

This skill is actively maintained and updated based on real-world usage.
