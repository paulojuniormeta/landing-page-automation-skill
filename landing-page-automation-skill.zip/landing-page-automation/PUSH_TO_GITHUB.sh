#!/bin/bash

# Script para fazer push da habilidade para o GitHub
# Execute este script localmente na sua máquina

echo "🚀 Landing Page Automation Skill - GitHub Push"
echo "=============================================="
echo ""

# Verificar se estamos no diretório correto
if [ ! -f "SKILL.md" ]; then
    echo "❌ Erro: Execute este script no diretório landing-page-automation-skill"
    exit 1
fi

# Configurar git (se necessário)
echo "📝 Configurando Git..."
git config user.name "Paulo Cardoni" 2>/dev/null || true
git config user.email "paulojuniormeta@gmail.com" 2>/dev/null || true

# Inicializar repositório (se necessário)
if [ ! -d ".git" ]; then
    echo "🔧 Inicializando repositório Git..."
    git init
    git add .
    git commit -m "Initial commit: Landing Page Automation Skill v2.0"
fi

# Adicionar remote
echo "🔗 Adicionando remote do GitHub..."
git remote remove origin 2>/dev/null || true
git remote add origin https://github.com/paulojuniormeta/landing-page-automation-skill.git

# Fazer push
echo "📤 Fazendo push para GitHub..."
git branch -M main
git push -u origin main

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Push realizado com sucesso!"
    echo ""
    echo "🎉 Sua habilidade está agora no GitHub:"
    echo "   https://github.com/paulojuniormeta/landing-page-automation-skill"
    echo ""
else
    echo ""
    echo "❌ Erro ao fazer push. Verifique suas credenciais do GitHub."
    echo ""
    echo "💡 Dicas:"
    echo "   1. Certifique-se de que o repositório existe no GitHub"
    echo "   2. Verifique suas credenciais (username/token)"
    echo "   3. Se usar 2FA, use um Personal Access Token"
    echo ""
fi
