# Landing Page Automation Skill

Automate creation of modern, mobile-first landing pages from existing URLs. This skill transforms outdated sales pages into responsive, high-performance landing pages in 15-20 minutes.

## 🎯 Use Cases

- **Recreate sales pages** with modern design (e.g., Hotmart pages)
- **Update outdated landing pages** to mobile-first responsive design
- **Automate page creation** for multiple products or courses
- **Test new designs quickly** without manual coding
- **Preserve existing functionality** while improving appearance

## ✨ Features

- ✅ **Mobile-First Design** - Optimized for all screen sizes
- ✅ **Preserves Original Content** - CTAs, tracking scripts, contact info
- ✅ **Fully Automated** - 8-phase automation process
- ✅ **Production Ready** - Deploy to Vercel in minutes
- ✅ **Reutilizable** - Use for unlimited projects
- ✅ **Well Documented** - Complete guides and examples

## 🚀 Quick Start

### Prerequisites

- Original URL (page to recreate)
- Reference URL (design inspiration)
- GitHub account with Personal Access Token
- Vercel account (free tier works)

### Usage

```bash
python scripts/landing_page_automation.py \
  --original-url "https://original.com" \
  --reference-url "https://reference.com" \
  --project-name "my-project" \
  --github-username "your-username" \
  --github-token "ghp_token"
```

### Result

- Public URL: `https://your-project.vercel.app`
- GitHub repository with full code
- Deployment logs and analytics

## 📚 Documentation

- **[SKILL.md](SKILL.md)** - Complete skill documentation
- **[references/workflow_guide.md](references/workflow_guide.md)** - Detailed 8-phase workflow
- **[references/react_components_mobile_first.md](references/react_components_mobile_first.md)** - Component templates

## 🏗️ Architecture

The automation runs 8 sequential phases:

| Phase | Name | Time |
|-------|------|------|
| 1 | Analysis | 2 min |
| 2 | Generation | 3 min |
| 3 | Structure | 1 min |
| 4 | Configuration | 1 min |
| 5 | Build | 3 min |
| 6 | GitHub | 2 min |
| 7 | Vercel | 3 min |
| 8 | Finalization | 1 min |

**Total: 15-20 minutes**

## 📦 What's Included

```
landing-page-automation-skill/
├── SKILL.md                                    # Main documentation
├── README.md                                   # This file
├── PUSH_TO_GITHUB.sh                          # GitHub push script
├── scripts/
│   └── landing_page_automation.py             # Main automation script
└── references/
    ├── workflow_guide.md                      # Detailed workflow
    ├── react_components_mobile_first.md       # Component templates
    └── api_reference.md                       # API reference
```

## 💡 Examples

### Example 1: Convert Hotmart Page

```bash
python scripts/landing_page_automation.py \
  --original-url "https://paulocardoni.hotmart.host/automacao-claude-code-trafego" \
  --reference-url "https://nocodestartup.io/formacao-agentic-builder/" \
  --project-name "automacao-claude-code-vendas" \
  --github-username "paulojuniormeta" \
  --github-token "ghp_xxxxxxxxxxxxx"
```

**Result:** Modern landing page deployed to Vercel with all original CTAs and tracking preserved.

### Example 2: Course Sales Page

```bash
python scripts/landing_page_automation.py \
  --original-url "https://my-course.com/sales" \
  --reference-url "https://example-modern.io/course/" \
  --project-name "my-course-2024" \
  --github-username "course-creator" \
  --github-token "ghp_xxxxxxxxxxxxx"
```

## 🔧 Customization

After deployment, customize by editing files and pushing to GitHub:

```bash
# Edit component
nano client/src/components/Hero.tsx

# Commit and push
git add .
git commit -m "Update hero section"
git push

# Vercel auto-deploys on push
```

## 📊 What Gets Preserved

- ✅ All CTAs and links
- ✅ Tracking scripts (Hotmart, GA, Facebook Pixel)
- ✅ Contact information
- ✅ Original content and text
- ✅ Compliance information (CNPJ, terms, privacy)

## 🎨 What Gets Improved

- ✅ Mobile-first responsive design
- ✅ Modern typography and spacing
- ✅ Color palette from reference
- ✅ Smooth animations and transitions
- ✅ Performance optimization

## 🔍 Troubleshooting

### Repository empty error
- Ensure Phase 6 completes successfully
- Check GitHub repository has files

### Build failed on Vercel
- Check Vercel build logs
- Verify package.json
- Test locally with `pnpm build`

### Page not responsive
- Review component Tailwind classes
- Ensure sm:, md:, lg: prefixes present

### CTA links not working
- Verify URLs in component files
- Test links manually

### Tracking scripts not firing
- Check index.html has script tags
- Verify Content Security Policy

## 🚀 Deployment

The skill automatically deploys to Vercel. After deployment:

1. Test on desktop and mobile
2. Validate all CTAs work
3. Check tracking scripts fire
4. Customize content as needed
5. Monitor performance

## 📈 Performance

Target metrics:
- First Contentful Paint: < 1.8s
- Largest Contentful Paint: < 2.5s
- Cumulative Layout Shift: < 0.1

## 🔒 Security

- HTTPS on all pages (Vercel provides free SSL)
- No sensitive data stored
- Only trusted tracking scripts
- Input validation and sanitization
- GDPR/CCPA compliant

## 📝 License

This skill is provided as-is for use with Manus AI platform.

## 🤝 Support

For issues or questions:

1. Check [SKILL.md](SKILL.md) documentation
2. Review [references/workflow_guide.md](references/workflow_guide.md)
3. Check troubleshooting section above

## 📊 Version

**Current version:** 2.0 (Mobile-First)  
**Last updated:** April 2026  
**Status:** Production-ready

---

**Ready to automate your landing page creation?** Start with the Quick Start section above! 🚀
